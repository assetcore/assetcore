#!/bin/bash
source config.file
#Install Ruby through rbenv:
rbenv install 2.2.1
rbenv global 2.2.1

#install bundler
echo "gem: --no-ri --no-rdoc" > ~/.gemrc
gem install bundler
rbenv rehash

# Install Mysql
#sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password password gatomorto'
#sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password_again password gatomorto'
sudo apt-get install -y mysql-server  mysql-client  libmysqlclient-dev

# Install Redis
sudo apt-add-repository -y ppa:chris-lea/redis-server
sudo apt-get update
sudo apt-get install -y redis-server

# Install RabbitMQ
sudo apt-add-repository 'deb http://www.rabbitmq.com/debian/ testing main'
curl http://www.rabbitmq.com/rabbitmq-release-signing-key.asc | sudo apt-key add -
sudo apt-get update
sudo apt-get install -y rabbitmq-server

sudo rabbitmq-plugins enable rabbitmq_management
sudo service rabbitmq-server restart
wget http://localhost:15672/cli/rabbitmqadmin
chmod +x rabbitmqadmin
sudo mv rabbitmqadmin /usr/local/sbin

# Install PhantomJS
sudo apt-get update
sudo apt-get install -y build-essential chrpath git-core libssl-dev libfontconfig1-dev
cd /usr/local/share
PHANTOMJS_VERISON=1.9.8
sudo wget https://bitbucket.org/ariya/phantomjs/downloads/phantomjs-$PHANTOMJS_VERISON-linux-x86_64.tar.bz2
sudo tar xjf phantomjs-$PHANTOMJS_VERISON-linux-x86_64.tar.bz2
sudo ln -s /usr/local/share/phantomjs-$PHANTOMJS_VERISON-linux-x86_64/bin/phantomjs /usr/local/share/phantomjs
sudo ln -s /usr/local/share/phantomjs-$PHANTOMJS_VERISON-linux-x86_64/bin/phantomjs /usr/local/bin/phantomjs
sudo ln -s /usr/local/share/phantomjs-$PHANTOMJS_VERISON-linux-x86_64/bin/phantomjs /usr/bin/phantomjs
cd -

#Install JavaScript Runtime
curl -sL https://deb.nodesource.com/setup | sudo bash -
sudo apt-get -y install nodejs

# Instlal ImageMagick
sudo apt-get install -y imagemagick
 
# Install Assetcore
# git clone https://github.com/assetcore/assetcore.git
cd assetcore

# Prepare configure files
bin/init_config
sed -i -e "s/gem 'mysql2'/gem 'mysql2', '~> 0.3.18'/g" Gemfile
bundle update mysql2
bundle install

# Update Pusher details
sed -i -e "s/YOUR_PUSHER_APP/$pusherapp/g" config/application.yml
sed -i -e "s/YOUR_PUSHER_KEY/$pusherkey/g" config/application.yml
sed -i -e "s/YOUR_PUSHER_SECRET/$pushersecret/g" config/application.yml

# Update Hostname 
sed -i -e "s/URL_HOST:/URL_HOST: $domainn:3000/g" config/application.yml


# Update Password Application
sed -i -e "s/password:/password: $mrpass/g" config/database.yml

#Deploy Database
bundle exec rake db:setup


#Update Mysql Admin User permissions
mysql -u root -p$mrpass assetcore_development -e "UPDATE members SET activated = '1' WHERE id='1'"
mysql -u root -p$mrpass assetcore_development -e "UPDATE id_documents SET aasm_state = 'verified' WHERE id='1'"
mysql -u root -p$mrpass assetcore_development -e "UPDATE two_factors SET activated = '0' WHERE id='1'"

# Starting all daemons
bundle exec rake daemons:start

# Starting Server
bundle exec rails server

