class TwoFactor::Email < ::TwoFactor

end
