module Admin
  module Statistic
    class BaseController < ::Admin::BaseController
    end
  end
end
