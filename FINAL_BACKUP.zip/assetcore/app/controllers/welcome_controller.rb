class WelcomeController < ApplicationController
  layout 'landing'

  def index
  end
end
